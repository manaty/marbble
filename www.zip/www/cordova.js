__cordovaRunningOnBrowser__ = true;
