var baseURL = '.wiktionary.org';
var LANG = {
    "en": "English",
    "fr": "French",
    "es": "Spanish",
    "tl": "Tagalog"
}
if(!navigator.onLine) {
  console.log("OFFLINE");
  document.getElementsByClassName("wordsDefinitionFlags")[0].style.display = "none";
  document.getElementById("definitionsSection").innerHTML = "<div style='text-align:center' id='offlineDefNotice'>You need an access to internet to see the definition</div>";
}
window.addEventListener('offline',  function() {
  console.log("OFFLINE");
  document.getElementsByClassName("wordsDefinitionFlags")[0].style.display = "none";
  document.getElementById("definitionsSection").innerHTML = "<div style='text-align:center' id='offlineDefNotice'>You need an access to internet to see the definition</div>";
});

window.addEventListener('online',  function() {
  document.getElementById("offlineDefNotice").remove();
  document.getElementsByClassName("wordsDefinitionFlags")[0].style.display = "table-row";
});

var fetchWiktionary = function(word, lang, style, type) {
  try {
    document.getElementById("definitionsSection").innerHTML = "";
    if(!navigator.onLine) {
      console.log("OFFLINE");
      document.getElementsByClassName("wordsDefinitionFlags")[0].style.display = "none";
      document.getElementById("definitionsSection").innerHTML = "<div style='text-align:center' id='offlineDefNotice'>You need an access to internet to see the definition</div>";
    }

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        // document.getElementById("demo").innerHTML = this.responseText;
        var resp = JSON.parse(this.responseText);
        var header = type == 1 ? "" : "<h2 class='"+style+"' style='text-align:center;'>"+word.toUpperCase()+"</h2>";
        document.getElementById("definitionsSection").innerHTML = header +resp.parse.text["*"];
        filterWiktionaryEntry("edit",lang);
      }
    };
    xhttp.open("GET", 'https://'+lang+baseURL+'/w/api.php?action=parse&origin=*&format=json&page='+word, true);
    xhttp.send();
  } catch(e) {
    console.log(e);
  }
};

var checkWiktionary = function(word, lang, style, type, source) {
  var appLanguage = window.applanguage[_languageSet];
  document.getElementById("definitionsSection").innerHTML = "";
  var saveSourceInnerHtml = source.innerHTML;
  source.innerHTML = "<img src='img/loading.gif' height='100%'/> Loading...";
  source.style.textAlign = "center !important";

  try {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        // document.getElementById("demo").innerHTML = this.responseText;
        var resp = JSON.parse(this.responseText);
        source.innerHTML = saveSourceInnerHtml;
        source.style.textAlign = "left !important";
        var header = type == 1 ? "" : "<h2 class='"+style+"' style='text-align:center;'>"+word.toUpperCase()+"</h2>";
        var test = header + resp.parse.text["*"];
        source.innerHTML += appLanguage.seeDefinition;
      }
    };

    xhttp.open("GET", 'https://'+lang+baseURL+'/w/api.php?action=parse&origin=*&format=json&page='+word, true);
    xhttp.send();
  } catch(e) {
    //DISPLAY ERROR
    console.log(e);

    source.innerHTML = saveSourceInnerHtml;
    source.innerHTML += appLanguage.noDefinition;
    return false;
  }
};

var filterWiktionaryEntry = function(type,lang) {
  if(type=="edit") {
    var paras = document.getElementsByClassName('mw-editsection');
    while(paras[0]) {
       paras[0].parentNode.removeChild(paras[0]);
    }
    var paras = document.getElementsByClassName('toctitle');
    while(paras[0]) {
       paras[0].parentNode.removeChild(paras[0]);
    }
    var paras = document.getElementsByClassName('toc');
    while(paras[0]) {
       paras[0].parentNode.removeChild(paras[0]);
    }
    var paras = document.getElementsByClassName('disambig-see-also-2');
    while(paras[0]) {
       paras[0].parentNode.removeChild(paras[0]);
    }
    var paras = document.getElementsByClassName('disambig-see-also');
    while(paras[0]) {
       paras[0].parentNode.removeChild(paras[0]);
    }
    var paras = document.getElementsByClassName('mw-headline');
    for(var i = 0; i < paras.length; i++) {
       if(paras[i].id == LANG[lang]) {
         paras[i].parentNode.removeChild(paras[i]);
       }
    }

    var paras = document.getElementById("definitionsSection").getElementsByTagName('a');
    for(var i = 0; i < paras.length; i++) {
       paras[i].href = "#";
     }

     var paras = document.getElementById("definitionsSection").getElementsByTagName('source');
     for(var i = 0; i < paras.length; i++) {
        var file = paras[i].src;
        file = file.replace("file://","http://");
        paras[i].src = file;
        if(file.startsWith("//upload.wikimedia.org")) {
          paras[i].src = "http:"+file;
        }
      }
  }
};
