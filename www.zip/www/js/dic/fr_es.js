if(!window.marbbleDic){
  window.marbbleDic={};
}
if(!window.marbbleDic.es){
  window.marbbleDic.es={};
}
window.marbbleDic.fr.es ={};
