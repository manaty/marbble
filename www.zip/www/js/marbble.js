"use strict";

var tileDragula;
var gameControler;
var sound;
var g_wstr = [];
function initMarbble(screenDivId, gameMode, language) {
    //we gives the responsibility of drag and drop rules to components themself
    tileDragula = dragula([], {
        moves: function moves(el, source, handle, sibling) {
            return el.draggable;
        },
        accepts: function accepts(el, target, source, sibling, mousePos) {
            var result = true;
            if (target.acceptsDropping) {
                result &= target.acceptsDropping(el, target, source, sibling, mousePos);
            }
            return result;
        }
    });

    var languageSet = window.applanguage[_languageSet];

    var player1 = getPlayer1Info();
    var player1Name = languageSet.player1;
    var player1Language = "en";
    var player1isComputer = false;

    var player2 = getPlayer2Info();
    var player2Name = languageSet.player1;
    var player2Language = "fr";
    var player2isComputer = false;

    if(player1) {
        player1Name = player1.name;
        player1Language = player1.language;
        player1isComputer = player1.isComputer;
    }

    if(player2) {
        player2Name = player2.name;
        player2Language = player2.language;
        player2isComputer = player2.isComputer;
        if(player2isComputer == "true") {
            player2Name = languageSet.computer;
        }
    }

    sound = new SoundControler();
    var isFirstTurn = true;

    var classicBag = null;
    var player1Bag = null;
    var player2Bag = null;

    if(gameMode == "Classic") {
        var classicBagControler = new BagControler(language, gameMode);
        classicBagControler.initBag("");
        classicBag = classicBagControler.getBag();
        player1Bag = classicBag;
        player2Bag = classicBag;

        player1Language = language;
        player2Language = language;
    }
    else if(gameMode == "MarbbleClassic") {
        var player1BagControler =  new BagControler(player1Language, gameMode);
        player1BagControler.initBag(0);
        player1Bag = player1BagControler.getBag();
        var player2BagControler =  new BagControler(player2Language, gameMode);
        player2BagControler.initBag(1);
        player2Bag = player2BagControler.getBag();
    }

    tileDragula.on("drag", onNodeDrag);
    tileDragula.on("drop", onNodeDrop);
    tileDragula.on("cancel", onNodeCancel);
    tileDragula.on("over", onNodeOver);
    gameControler = new GameControler(screenDivId, gameMode, language);
    gameControler.addPlayer(player1Name, player1Language, player1isComputer, player1Bag);
    gameControler.drawDivider();
    gameControler.addPlayer(player2Name, player2Language, player2isComputer, player2Bag);
    gameControler.draw(isFirstTurn);
    _windowOpened = 'gameScreenWindow';

}

function onNodeOver(el, target, source) {

    if(el.component && el.component.onOver) {
        el.component.onOver(el, target, source);
    }

    if(target && target.onOver) {
        target.onOver(el, target, source);
    }

}

function onNodeDrag(el, source) {

    if (el.component && el.component.onDragged) {
        el.component.onDragged(el, source);
    }
    if (source.onDraggedFrom) {
        source.onDraggedFrom(el, source);
    }

    //play sound
    sound.plungerPopTileOff();
}

function onNodeDrop(el, target, source, sibling, mousePos) {

    if (el.component && el.component.onDropped) {
        el.component.onDropped(el, target, source, sibling, mousePos);
    }

    if (target.onDropped) {
        target.onDropped(el, target, source, sibling, mousePos);
    }

    //play sound
    sound.bubblePopTileOn();

}

function onNodeCancel(el, target, source) {
    if (el.component && el.component.onCanceled) {
        el.component.onCanceled(el, target, source);
    }
}

function getSupportedLocalStorage(){
    try
    {
        var localStorage = window.localStorage;
        var testKey = 'isLocalStorageSupported';
        localStorage.setItem(testKey, '1');
        localStorage.removeItem(testKey);
        return localStorage;
    }
    catch (error)
    {
        console.log(error);
        console.log("Local storage may not be supported");
        return null;
    }
}

function getPlayer1Info() {
    var playerKey = 'player1Name';
    var playerLanguage = 'player1Language';
    var player1isComputerKey = 'player1isComputer';
    var localStorage = getSupportedLocalStorage();

    var languageSet = window.applanguage[_languageSet];

    if(localStorage) {
        var playerName = localStorage.getItem(playerKey) != null ? localStorage.getItem(playerKey) : languageSet.player1;
        var playerLanguage = localStorage.getItem(playerLanguage) != null ? localStorage.getItem(playerLanguage) : "en";
        var isComputer = localStorage.getItem(player1isComputerKey) != null ? localStorage.getItem(player1isComputerKey) : false;

        var data = {
            name : playerName,
            language: playerLanguage,
            isComputer: isComputer
        };

        return data;
    }
    return null;
}

function getPlayer2Info() {
    var playerKey = 'player2Name';
    var playerLanguage = 'player2Language';
    var playAgainstComputerKey = 'playAgainstComputer';
    var player2isComputerKey = 'player2isComputer';
    var localStorage = getSupportedLocalStorage();
    var languageSet = window.applanguage[_languageSet];

    if(localStorage) {
        var playerName = localStorage.getItem(playerKey) != null ? localStorage.getItem(playerKey) : languageSet.player2;
        var playerLanguage = localStorage.getItem(playerLanguage) != null ? localStorage.getItem(playerLanguage) : "fr";
        var isComputer = localStorage.getItem(player2isComputerKey) != null ? localStorage.getItem(player2isComputerKey) : false;

        var data = {
            name : playerName,
            language: playerLanguage,
            isComputer: isComputer
        };

        return data;
    }
    return null;
}
