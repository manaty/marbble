if(!window.marbbleDic){
  window.marbbleDic={};
}
if(!window.marbbleDic.tl){
  window.marbbleDic.tl={};
}
window.marbbleDic.tl.es = {};
