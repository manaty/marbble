if(!window.marbbleDic){
  window.marbbleDic={};
}
if(!window.marbbleDic.en){
  window.marbbleDic.en={};
}
window.marbbleDic.en.tl = { };
