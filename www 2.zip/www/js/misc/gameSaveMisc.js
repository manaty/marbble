// ai_pass
// board
//  TILE - if not player
//  if not played, circular because of Component inside
// g_board
//g_playlevel
//movesHistory
//playLevel
//playerToPlay
//players - circular
//round
//status
//type
//wordsPlayed


var saveState = function(data) {
  console.log(data);
  var state = {
    ai_pass: data.ai_pass,
    board: JSON.parse(decircularise(data.board)),
    g_board: data.g_board,
    g_playlevel: data.g_playlevel,
    movesHistory: data.movesHistory,
    playLevel: data.playLevel,
    playerToPlay: data.playerToPlay,
    //players
    round: data.round,
    status: data.status,
    type: data.type,
    wordsPlayed: data.wordsPlayed
  }

  console.log(state);
  var storage = window.localStorage;
  storage.setItem("board", JSON.stringify(state.board));
  storage.setItem("game", JSON.stringify(state));
};

const decircularise = function (v) {
  const cache = new Map();
  return JSON.stringify(v, function (key, value) {
    if (typeof value === 'object' && value !== null) {
      if (cache.get(value)) {
        // Circular reference found, discard key
        return;
      }
      // Store value in our map
      cache.set(value, true);
    }
    return value;
  });
};
