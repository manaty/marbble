"use strict";

var mainInterface;

// Production steps of ECMA-262, Edition 6, 22.1.2.1
//Fix for Array.from issue with ES6 on Android webview
if (!Array.from) {
  Array.from = (function () {
    var toStr = Object.prototype.toString;
    var isCallable = function (fn) {
      return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
    };
    var toInteger = function (value) {
      var number = Number(value);
      if (isNaN(number)) { return 0; }
      if (number === 0 || !isFinite(number)) { return number; }
      return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
    };
    var maxSafeInteger = Math.pow(2, 53) - 1;
    var toLength = function (value) {
      var len = toInteger(value);
      return Math.min(Math.max(len, 0), maxSafeInteger);
    };

    // The length property of the from method is 1.
    return function from(arrayLike/*, mapFn, thisArg */) {
      // 1. Let C be the this value.
      var C = this;

      // 2. Let items be ToObject(arrayLike).
      var items = Object(arrayLike);

      // 3. ReturnIfAbrupt(items).
      if (arrayLike == null) {
        throw new TypeError('Array.from requires an array-like object - not null or undefined');
      }

      // 4. If mapfn is undefined, then let mapping be false.
      var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
      var T;
      if (typeof mapFn !== 'undefined') {
        // 5. else
        // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
        if (!isCallable(mapFn)) {
          throw new TypeError('Array.from: when provided, the second argument must be a function');
        }

        // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
        if (arguments.length > 2) {
          T = arguments[2];
        }
      }

      // 10. Let lenValue be Get(items, "length").
      // 11. Let len be ToLength(lenValue).
      var len = toLength(items.length);

      // 13. If IsConstructor(C) is true, then
      // 13. a. Let A be the result of calling the [[Construct]] internal method
      // of C with an argument list containing the single item len.
      // 14. a. Else, Let A be ArrayCreate(len).
      var A = isCallable(C) ? Object(new C(len)) : new Array(len);

      // 16. Let k be 0.
      var k = 0;
      // 17. Repeat, while k < len… (also steps a - h)
      var kValue;
      while (k < len) {
        kValue = items[k];
        if (mapFn) {
          A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
        } else {
          A[k] = kValue;
        }
        k += 1;
      }
      // 18. Let putStatus be Put(A, "length", len, true).
      A.length = len;
      // 20. Return A.
      return A;
    };
  }());
}

var MainInterface = function () {
    var self = this;

    self.selectedLanguage = "";

    self.docW = document.documentElement.clientWidth;
    self.docH = document.documentElement.clientHeight;
    self.gameType = "passAndPlay";

    self.loadedScripts = 0;
    self.scriptsToLoad = 0;
    self.src = [];
    self.scripts = [];
    self.scriptIds = [];
    self.gameMode = "MarbbleClassic";
    self.classicLanguage = null;
    self.parentUrl = "";

    self.sound = new SoundControler();

    self.init = function() {
        window.onload = self.initMainScreen();
    };

    self.initMainScreen = function() {

        window.addEventListener('message', function(event) {

            if(event.data) {
                self.parentUrl = event.data;

                var isRunningOnBrowser = window.__cordovaRunningOnBrowser__;

                if(isRunningOnBrowser) {

                    self.getAppLanguage();
                    self.updateGameTexts();
                    self.updateGameButtonLocale();

                }
            }
        });

        var screenDiv = document.getElementById("marbblescreen");
        self.screenDiv = screenDiv;
        self.manatySplashScreen = document.getElementById("manatySplashScreen");
        self.marbbleSplashScreen = document.getElementById("marbbleSplashScreen");
        var mainMenuDiv = document.getElementById("mainMenu");
        self.mainMenuDiv = mainMenuDiv;
        var mainMenuBtn = document.getElementById("mainMenuBtn");
        var newGameBtn = document.getElementById("newGameBtn");
        var settingsBtn = document.getElementById("settingsBtn");
        var gameConfigPopupDiv = document.getElementById("gameConfigModal");
        var notImplementedPopupDiv = document.getElementById("showModalDialog");
        var passAndPlayBtn = document.getElementById("passAndPlayBtn");
        var passAndPlayTab = document.getElementById("passAndPlayTab");
        var playAgainstComputerTab = document.getElementById("playAgainstComputerTab");
        self.gamePlayBtn = document.getElementById("gamePlayBtn");
        var playWithFriendBtn = document.getElementById("playWithFriend");
        var findOpponentBtn = document.getElementById("findOpponent");
        var soloGameBtn = document.getElementById("soloGame");
        var cancelGameBtn = document.getElementById("cancelGameBtn");
        self.marbbleClassicBtn = document.getElementById("marbbleClassicBtn");
        self.marbbleSpecialBtn = document.getElementById("marbbleSpecialBtn");
        self.classicBtn = document.getElementById("classicBtn");
        self.gameModeText = document.getElementById("gameModeText");
        self.gameModeIcon = document.getElementById("gameModeIcon");
        var editLanguagesBtn = document.getElementById("editLanguagesBtn");
        var player1LanguageEnBtn = document.getElementById("player1LanguageEn");
        var player1LanguageFrBtn = document.getElementById("player1LanguageFr");
        var player1LanguageEsBtn = document.getElementById("player1LanguageEs");
        var player1LanguageTlBtn = document.getElementById("player1LanguageTl");
        var player2LanguageEnBtn = document.getElementById("player2LanguageEn");
        var player2LanguageFrBtn = document.getElementById("player2LanguageFr");
        var player2LanguageEsBtn = document.getElementById("player2LanguageEs");
        var player2LanguageTlBtn = document.getElementById("player2LanguageTl");
        var classicLanguageEnBtn = document.getElementById("classicLanguageEn");
        var classicLanguageFrBtn = document.getElementById("classicLanguageFr");
        var classicLanguageEsBtn = document.getElementById("classicLanguageEs");
        var classicLanguageTlBtn = document.getElementById("classicLanguageTl");
        var modalCloseButton = document.getElementById("close");
        self.creditsScreen = document.getElementById("creditsScreen");
        self.creditsBackButton = document.getElementById("creditBack");
        self.soundButton = document.getElementById("soundButton");
        self.gameModeScreen = document.getElementById("gameModeScreen");

        self.exitAppPopupDiv = document.getElementById("exitAppModalDialog");

        self.exitOKButton = document.getElementById('exitOKButton');
        self.exitCancelButton = document.getElementById('exitCancelButton');

        self.localStorage = self.getSupportedLocalStorage();

        if(self.exitCancelButton) {
            self.exitCancelButton.addEventListener('click', self.hideExitAppDialog);
        }

        if(self.exitOKButton) {
            self.exitOKButton.addEventListener('click', self.exitApp);
        }

        var tipeeeLink = document.getElementById("tipeeeLink");

        var creditsButton = document.getElementById("credits");


        self.scriptsToLoad = 0;

        if(creditsButton) {
            creditsButton.addEventListener('click', self.openCredits);
        }

        if(tipeeeLink) {
            var isRunningOnBrowser = window.__cordovaRunningOnBrowser__;

            if(!isRunningOnBrowser) {
                tipeeeLink.addEventListener('click', self.tipeeeLinkClick);
            }
        }

        if(self.creditsBackButton) {
            self.creditsBackButton.addEventListener('click', self.backToMainMenu);
        }

        if(passAndPlayBtn) {
            passAndPlayBtn.addEventListener('click', self.passAndPlaySelected);
        }

        if(self.marbbleClassicBtn) {
            marbbleClassicBtn.addEventListener('click', self.selectMarbbleClassicMode);
        }

        if(self.marbbleSpecialBtn) {
            self.marbbleSpecialBtn.style.opacity = "0.5";
            marbbleSpecialBtn.addEventListener('click', self.selectMarbbleSpecialMode);
        }

        if(self.classicBtn) {
            classicBtn.addEventListener('click', self.selectClassicMode);
        }

        if(mainMenuBtn) {
            mainMenuBtn.addEventListener('click', self.showNotImplementedPopup);
        }

        if(newGameBtn) {
            //newGameBtn.addEventListener('click', self.showGameConfigPopup);
        }

        if(settingsBtn) {
            settingsBtn.addEventListener('click', self.showNotImplementedPopup);
        }

        if(self.gamePlayBtn) {
            self.gamePlayBtn.addEventListener('click', self.startPlay);
        }


        if(cancelGameBtn) {
            cancelGameBtn.addEventListener('click', self.hideGameModeScreen);
        }

        if(player1LanguageEnBtn) {
            player1LanguageEnBtn.setAttribute('isselected', false);
            player1LanguageEnBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player1LanguageFrBtn) {
            player1LanguageFrBtn.setAttribute('isselected', false);
            player1LanguageFrBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player1LanguageEsBtn) {
            player1LanguageEsBtn.setAttribute('isselected', false);
            player1LanguageEsBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player1LanguageTlBtn) {
            player1LanguageTlBtn.setAttribute('isselected', false);
            player1LanguageTlBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player2LanguageEnBtn) {
            player2LanguageEnBtn.setAttribute('isselected', false);
            player2LanguageEnBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player2LanguageFrBtn) {
            player2LanguageFrBtn.setAttribute('isselected', false);
            player2LanguageFrBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player2LanguageEsBtn) {
            player2LanguageEsBtn.setAttribute('isselected', false);
            player2LanguageEsBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(player2LanguageTlBtn) {
            player2LanguageTlBtn.setAttribute('isselected', false);
            player2LanguageTlBtn.addEventListener('click', self.toggleSelectedLanguage);
        }

        if(classicLanguageEnBtn) {
            classicLanguageEnBtn.setAttribute('isselected', false);
            classicLanguageEnBtn.addEventListener('click', self.toggleClassicLanguage);
        }

        if(classicLanguageFrBtn) {
            classicLanguageFrBtn.setAttribute('isselected', false);
            classicLanguageFrBtn.addEventListener('click', self.toggleClassicLanguage);
        }

        if(classicLanguageEsBtn) {
            classicLanguageEsBtn.setAttribute('isselected', false);
            classicLanguageEsBtn.addEventListener('click', self.toggleClassicLanguage);
        }

        if(classicLanguageTlBtn) {
            classicLanguageTlBtn.setAttribute('isselected', false);
            classicLanguageTlBtn.addEventListener('click', self.toggleClassicLanguage);
        }

        if(modalCloseButton) {
            modalCloseButton.addEventListener('click', self.hideNotImplementedPopup);
        }

        if(playWithFriendBtn) {
            playWithFriendBtn.addEventListener('click', self.showNotImplementedPopup);
        }

        if(findOpponentBtn) {
            findOpponentBtn.addEventListener('click', self.showNotImplementedPopup);
        }

        if(soloGameBtn) {
            //soloGameBtn.addEventListener('click', self.showGameConfigPopupSolo);
            soloGameBtn.addEventListener('click', self.soloPlaySelected);
        }

        if(editLanguagesBtn) {
            editLanguagesBtn.addEventListener('click', self.showNotImplementedPopup);
        }

        if(self.soundButton) {
            self.soundButton.addEventListener('click', self.toggleSoundButton);
        }

        var isMobile = self.isMobile();

        if(isMobile == false) {
            self.docW = 360;
            self.docH = 640;
            screenDiv.style.border = "3px solid #ffffff";
        }

        screenDiv.style.width = self.docW + "px";
        screenDiv.style.height = self.docH + "px";

        if(gameConfigPopupDiv) {
            gameConfigPopupDiv.style.width = self.docW + "px";
            gameConfigPopupDiv.style.height = self.docH + "px";
        }

        if(notImplementedPopupDiv) {
            notImplementedPopupDiv.style.width = self.docW + "px";
            notImplementedPopupDiv.style.height = self.docH + "px";
        }

        if(self.exitAppPopupDiv) {
            self.exitAppPopupDiv.style.width = self.docW + "px";
            self.exitAppPopupDiv.style.height = self.docH + "px";
        }

         var body = document.getElementsByTagName("body")[0];
         body.style.display = "block";

         var enFlagDiv = document.getElementById("enFlag");
         var frFlagDiv = document.getElementById("frFlag");
         var esFlagDiv = document.getElementById("esFlag");
         var deFlagDiv = document.getElementById("deFlag");


         // var isRunningOnBrowser = window.__cordovaRunningOnBrowser__;
         //
         // if(isRunningOnBrowser) {
         //
         //     self.getAppLanguage();
         //     self.updateGameTexts();
         //     self.updateGameButtonLocale();
         //
         // }

         self.startManatySplash();


    };

    self.isMobile = function() {

        if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) && self.docW > 1024) {
            return false;
        }
        return true;

    };

    self.toggleSoundButton = function(e) {
        var soundButtonValue = self.getSoundButtonValue();
        var div = self.soundButton;

        if(soundButtonValue == true || soundButtonValue == "true") {
            div.classList.remove("player_config_soundON");
            div.classList.add("player_config_soundOFF");
            soundButtonValue = false;
        }
        else {
            div.classList.remove("player_config_soundOFF");
            div.classList.add("player_config_soundON");
            soundButtonValue = true;
        }
        self.setSoundButtonValue(soundButtonValue);
    };

    self.getGameModeSelected = function(e) {
        var gameModeValue = document.getElementById("gameModeSelected").value;
        return gameModeValue;
    };

    self.setGameModeSelected = function(val) {
        var gameModeSelected = document.getElementById("gameModeSelected");
        gameModeSelected.value = val;
    };

    self.getSoundButtonValue = function(e) {
        var soundButtonValue = document.getElementsByName("soundButtonValue")[0].value.trim();
        return soundButtonValue;
    };

    self.setSoundButtonValue = function(val) {
        var soundButton = document.getElementsByName("soundButtonValue")[0];
        soundButton.value = val;
    };

    self.getPlayer1Input = function(e) {
        var player1Input = document.getElementsByName("player1pseudo")[0].value.trim();
        return player1Input;
    };

    self.getPlayer2Input = function(e) {
        var player2Input = document.getElementsByName("player2pseudo")[0].value.trim();
        return player2Input;
    };

    self.getPlayer1Language = function(e) {
        var playerLanguage = document.getElementsByName("player1Language")[0].value;
        return playerLanguage;
    };

    self.getPlayer2Language = function(e) {
        var playerLanguage = document.getElementsByName("player2Language")[0].value;
        return playerLanguage;
    };

    self.getClassicLanguage = function(e) {
        var classicLanguage = document.getElementsByName("classicLanguage")[0].value;
        return classicLanguage;
    }


    self.setPlayerInfoFromStorage = function() {
        var player1Input = document.getElementsByName("player1pseudo")[0];
        var player2Input = document.getElementsByName("player2pseudo")[0];
        var player1LanguageInput = document.getElementsByName("player1Language")[0];
        var player2LanguageInput = document.getElementsByName("player2Language")[0];
        var classicLanguageInput = document.getElementsByName("classicLanguage")[0];
        var classicLanguageEn = document.getElementById("classicLanguageEn");
        var classicLanguageFr = document.getElementById("classicLanguageFr");
        var classicLanguageEs = document.getElementById("classicLanguageEs");
        var classicLanguageTl = document.getElementById("classicLanguageTl");

        var soundButton = document.getElementsByName("soundButtonValue")[0];

        var gameModeSelected = document.getElementById('gameModeSelected');

        var player1LanguageEn = document.getElementById("player1LanguageEn");
        var player1LanguageFr = document.getElementById("player1LanguageFr");
        var player1LanguageEs = document.getElementById("player1LanguageEs");
        var player1LanguageTl = document.getElementById("player1LanguageTl");
        var player2LanguageEn = document.getElementById("player2LanguageEn");
        var player2LanguageFr = document.getElementById("player2LanguageFr");
        var player2LanguageEs = document.getElementById("player2LanguageEs");
        var player2LanguageTl = document.getElementById("player2LanguageTl");

        var player1NameKey = 'player1Name';
        var player2NameKey = 'player2Name';
        var player1LanguageKey = 'player1Language';
        var player2LanguageKey = 'player2Language';

        var soundButtonValueKey = 'soundButtonKey';

        var gameModeKey = 'gameModeKey';

        var classicLanguageKey = 'classicLanguageKey';

        player1LanguageEn.classList.remove('selected');
        player1LanguageFr.classList.remove('selected');
        player1LanguageEs.classList.remove('selected');
        player1LanguageTl.classList.remove('selected');

        player2LanguageEn.classList.remove('selected');
        player2LanguageFr.classList.remove('selected');
        player2LanguageEs.classList.remove('selected');
        player2LanguageTl.classList.remove('selected');

        classicLanguageEn.classList.remove('selected');
        classicLanguageFr.classList.remove('selected');
        classicLanguageEs.classList.remove('selected');
        classicLanguageTl.classList.remove('selected');

        self.marbbleClassicBtn.classList.remove('active');
        self.marbbleSpecialBtn.classList.remove('active');
        self.classicBtn.classList.remove('active');

        if(self.localStorage) {
            var player1Name = self.localStorage.getItem(player1NameKey);

            if(player1Name && player1Name != '') {
                player1Input.value = player1Name;
            }

            var player2Name = self.localStorage.getItem(player2NameKey);

            if(player2Name && player2Name != '') {
                player2Input.value = player2Name;
            }

            var player1Language = self.localStorage.getItem(player1LanguageKey);

            if(player1Language) {
                if(player1Language == "en") {
                    player1LanguageEn.classList.add("selected");
                }
                else if(player1Language == "fr") {
                    player1LanguageFr.classList.add("selected");
                }
                else if(player1Language == "es") {
                    player1LanguageTl.classList.add("selected");
                }
                else if(player1Language == "tl") {
                    player1LanguageTl.classList.add("selected");
                }
                player1LanguageInput.value = player1Language;
            }
            else {
                console.log('no language for player 1 set...');
                //set to english the default language of player 1
                player1LanguageEn.classList.add('selected');
                player1LanguageInput.value = "en";
            }

            var player2Language = self.localStorage.getItem(player2LanguageKey);

            if(player2Language) {
                if(player2Language == "en") {
                    player2LanguageEn.classList.add("selected");
                }
                else if(player2Language == "fr") {
                    player2LanguageFr.classList.add("selected");
                }
                else if(player2Language == "es") {
                    player2LanguageTl.classList.add("selected");
                }
                else if(player2Language == "tl") {
                    player2LanguageTl.classList.add("selected");
                }
                player2LanguageInput.value = player2Language;
            }
            else {
                console.log('no language for player 2 set...');
                //set to french the default language of player 2
                player2LanguageFr.classList.add('selected');
                player2LanguageInput.value = "fr";
            }

            var classicLanguage = self.localStorage.getItem(classicLanguageKey);

            if(classicLanguage) {
                if(classicLanguage == "en") {
                    classicLanguageEn.classList.add("selected");
                }
                else if(classicLanguage == "fr") {
                    classicLanguageFr.classList.add("selected");
                }
                else if(classicLanguage == "es") {
                    classicLanguageEs.classList.add("selected");
                }
                else if(classicLanguage == "tl") {
                    classicLanguageTl.classList.add("selected");
                }
            } else {
                console.log('no classic language set...');
                //set to english the default language
                classicLanguageEn.classList.add('selected');
                classicLanguageInput.value = "en";
            }

            var soundButtonValue = self.localStorage.getItem(soundButtonValueKey);


            if(soundButtonValue != null) {

                var div = self.soundButton;

                if(soundButtonValue == true || soundButtonValue == "true") {
                    div.classList.remove("player_config_soundOFF");
                    div.classList.add("player_config_soundON");
                }
                else {
                    div.classList.remove("player_config_soundON");
                    div.classList.add("player_config_soundOFF");
                }
                self.setSoundButtonValue(soundButtonValue);
            }
            else {
                soundButton.value = self.getSoundButtonValue();
            }

            var gameModeValue = self.localStorage.getItem(gameModeKey);

            if(gameModeValue) {
                gameModeSelected.value = gameModeValue;
                self.gameMode = gameModeValue;
                if(gameModeValue == "MarbbleClassic") {
                    self.showMarbbleClassicModeOptions();
                }
                else if(gameModeValue == "MarbbleSpecial") {
                    //self.marbbleSpecialBtn.classList.add('active');
                }
                else {

                    self.showClassicModeOptions();

                }
            }
            else {
                //no value selected
                if(self.gameMode == "MarbbleClassic") {
                    self.selectMarbbleClassicMode();
                }
                else if(self.gameMode == "MarbbleSpecial") {
                    //self.marbbleSpecialBtn.classList.add('active');
                }
                else {
                    self.selectClassicMode();
                }
                gameModeSelected.value = self.gameMode;
            }


        }

    };

    self.startPlay = function(e) {
        //temporarily disable for classic mode

        var player1Input = self.getPlayer1Input();
        var player2Input = self.getPlayer2Input();
        var player1LanguageInput = self.getPlayer1Language();
        var player2LanguageInput = self.getPlayer2Language();
        var classicLanguage = self.getClassicLanguage();
        self.classicLanguage = classicLanguage;
        var language = window.applanguage[_languageSet];

        if(self.gameMode == "Classic") {
            console.log('classic language: ' + classicLanguage);
            // self.showNotImplementedPopup();
            // return;
        }
        else if(self.gameMode == "MarbbleClassic") {

            //For MarbbleClassic, same language is not allowed for both players
            if(player1LanguageInput == player2LanguageInput) {
                var errorMessage = language.selectDifferentLanguage;
                self.showErrorMessage(errorMessage);
                return;
            }
        }

        var soundButtonValue = self.getSoundButtonValue();

        var gameModeSelected = self.getGameModeSelected();

        var player1NameKey = 'player1Name';
        var player2NameKey = 'player2Name';
        var player1LanguageKey = 'player1Language';
        var player2LanguageKey = 'player2Language';
        var player1isComputerKey = 'player1isComputer';
        var player2isComputerKey = 'player2isComputer';
        var soundButtonValueKey = 'soundButtonKey';
        var gameModeKey = 'gameModeKey';
        var classicLanguageKey = 'classicLanguageKey';

    	if(self.localStorage) {


            if(player1Input) {
                self.localStorage.setItem(player1NameKey, player1Input);
            }

            if(player2Input) {
                self.localStorage.setItem(player2NameKey, player2Input);
            }

            if(player1LanguageInput) {
                self.localStorage.setItem(player1LanguageKey, player1LanguageInput);
            }

            if(player2LanguageInput) {
                self.localStorage.setItem(player2LanguageKey, player2LanguageInput);
            }

            if(gameModeSelected) {
                self.localStorage.setItem(gameModeKey, gameModeSelected);
            }

            if(classicLanguage) {
                self.localStorage.setItem(classicLanguageKey, classicLanguage);
            }

            var isComputer = self.gameType == 'soloPlay' ? true : false;

            self.localStorage.setItem(player1isComputerKey, false);

            self.localStorage.setItem(player2isComputerKey, isComputer);

            self.localStorage.setItem(soundButtonValueKey, soundButtonValue);

            if(isComputer) {
                for(var i=0; i < 5; i++) {
                    if(document.getElementById("size_"+(i+1)).checked) {
                      self.localStorage.setItem("aiDifficulty", i);
                    }
                }
            }


            self.hideGameModeScreen();

            self.loadGame();

        }
    };

    self.loadScriptsSync = function(scriptIds, _scripts, scripts) {
        var x = 0;

        var loopArray = function(scriptIds, _scripts, scripts) {
            //call itself

            self.loadScript(scriptIds[x], _scripts[x], scripts[x], function(){
                // set x to next item
                x++;
                if(x < _scripts.length) {
                    loopArray(scriptIds, _scripts, scripts);
                }
                else {
                    self.src = [];
                    self.scriptIds = [];
                    gameControler.component.hideLoader();
                }
            });
        };
        loopArray(scriptIds, _scripts, scripts);
    };

    self.loadGame = function() {

        self.mainMenuDiv.style.display = 'none';
        initMarbble('marbblescreen', self.gameMode, self.classicLanguage);
        self.loadDictionary();
    };

    self.showExitAppDialog = function() {
        if(self.exitAppPopupDiv) {
            self.exitAppPopupDiv.style.display = "block";
        }
    };

    self.hideExitAppDialog = function() {

        if(self.exitAppPopupDiv) {
            self.exitAppPopupDiv.style.display = "none";
        }
    }

    self.exitApp = function() {
        self.hideExitAppDialog();
        if(navigator && navigator.app)
        {
            navigator.app.exitApp();
        }

    };

    self.loadScript = function(id, src, script, callback) {
        var isRunningOnBrowser = window.__cordovaRunningOnBrowser__;

        if(!isRunningOnBrowser) {
           gameControler.component.showLoader();
        }

        script = document.createElement('script');
        var r, t = false;

        script.type = 'text/javascript';
        script.id = id;
        script.src = src;
        script.onerror = function(e) {
            // handling error when loading script
            console.log('Error to handle');
            console.log(e);
            gameControler.component.hideLoader();
        }

        script.onload = script.onreadystatechange = function() {
            if ( !r && (!this.readyState || this.readyState == 'complete') ) {
              r = true;
              callback();
            }
        };

        t = document.getElementsByTagName('script')[document.getElementsByTagName('script').length -1];
        t.parentNode.insertBefore(script, t.nextSibling);
    };


    self.loadDictionary = function() {


        var lang1 = self.getPlayer1Language();
        var lang2 = self.getPlayer2Language();

        var src = "js/dic/full_"+lang1+"_"+lang2+".js";

        var dictionaryId = 'dic_' + lang1 + '_' + lang2;
        var checkSrc = document.getElementById(dictionaryId);

        if(!checkSrc) {
            if(lang1 != lang2) {
                self.src.push(src);
                self.scriptIds.push(dictionaryId);
            }
        }


        src = "js/dic/full_"+lang2+"_"+lang1+".js";
        dictionaryId = 'dic_' + lang2 + '_' + lang1;

        checkSrc = document.getElementById(dictionaryId);
        if(!checkSrc) {
            if(lang1 != lang2) {
                self.src.push(src);
                self.scriptIds.push(dictionaryId);
            }
        }

        src = "js/wordlist/full/"+lang1+"_wordlist.js";
        var wordlistId = 'wordlist_' + lang1;

        checkSrc = document.getElementById(wordlistId);
        if(!checkSrc) {
            self.src.push(src);
            self.scriptIds.push(wordlistId);
        }

        src = "js/wordlist/full/"+lang2+"_wordlist.js";
        wordlistId = 'wordlist_' + lang2;

        checkSrc = document.getElementById(wordlistId);
        if(!checkSrc) {
            self.src.push(src);
            self.scriptIds.push(wordlistId);
        }

        var scripts = [];

        if(self.scriptIds.length > 0) {
            self.loadScriptsSync(self.scriptIds, self.src, scripts);
        }


    };

    self.enablePlayerLanguage = function(id) {
        var player1LanguageEn = document.getElementById("player1LanguageEn");
        var player1LanguageFr = document.getElementById("player1LanguageFr");
        var player1LanguageEs = document.getElementById("player1LanguageEs");
        var player1LanguageTl = document.getElementById("player1LanguageTl");
        var player2LanguageEn = document.getElementById("player2LanguageEn");
        var player2LanguageFr = document.getElementById("player2LanguageFr");
        var player2LanguageEs = document.getElementById("player2LanguageEs");
        var player2LanguageTl = document.getElementById("player2LanguageTl");

        player1LanguageEn.style.opacity = 1.0;
        player1LanguageFr.style.opacity = 1.0;
        player1LanguageEs.style.opacity = 1.0;
        player1LanguageTl.style.opacity = 1.0;

        player2LanguageEn.style.opacity = 1.0;
        player2LanguageFr.style.opacity = 1.0;
        player2LanguageEs.style.opacity = 1.0;
        player2LanguageTl.style.opacity = 1.0;
    };

    self.disablePlayerLanguage = function(id) {
        var player1LanguageEn = document.getElementById("player1LanguageEn");
        var player1LanguageFr = document.getElementById("player1LanguageFr");
        var player1LanguageEs = document.getElementById("player1LanguageEs");
        var player1LanguageTl = document.getElementById("player1LanguageTl");
        var player2LanguageEn = document.getElementById("player2LanguageEn");
        var player2LanguageFr = document.getElementById("player2LanguageFr");
        var player2LanguageEs = document.getElementById("player2LanguageEs");
        var player2LanguageTl = document.getElementById("player2LanguageTl");

        var player1Language = document.getElementsByName("player1Language")[0];
        var player2Language = document.getElementsByName("player2Language")[0];

        self.enablePlayerLanguage();

        if(id == "player1LanguageEn") {
            player2LanguageEn.classList.remove("selected");
            player2LanguageEn.style.opacity = 0.5;
        }
        else if(id == "player1LanguageFr") {
            player2LanguageFr.classList.remove("selected");
            player2LanguageFr.style.opacity = 0.5;
        }
        else if(id == "player1LanguageEs") {
            player2LanguageEs.classList.remove("selected");
            player2LanguageEs.style.opacity = 0.5;
        }
        else if(id == "player1LanguageTl") {
            player2LanguageTl.classList.remove("selected");
            player2LanguageTl.style.opacity = 0.5;
        }
        else if(id == "player2LanguageEn") {
            player1LanguageEn.classList.remove("selected");
            player1LanguageEn.style.opacity = 0.5;
        }
        else if(id == "player2LanguageFr") {
            player1LanguageFr.classList.remove("selected");
            player1LanguageFr.style.opacity = 0.5;
        }
        else if(id == "player2LanguageEs") {
            player1LanguageEs.classList.remove("selected");
            player1LanguageEs.style.opacity = 0.5;
        }
        else if(id == "player2LanguageTl") {
            player1LanguageTl.classList.remove("selected");
            player1LanguageTl.style.opacity = 0.5;
        }

    };

    self.toggleClassicLanguage = function(e) {

        var div = e.target;
        var classicLanguage = document.getElementsByName("classicLanguage")[0];
        var classicLanguageEn = document.getElementById("classicLanguageEn");
        var classicLanguageFr = document.getElementById("classicLanguageFr");
        var classicLanguageEs = document.getElementById("classicLanguageEs");
        var classicLanguageTl = document.getElementById("classicLanguageTl");

        var isSelected = div.classList.contains('selected');

        if(div.id == "classicLanguageEn") {
            if(!isSelected) {
                div.classList.toggle("selected");
                classicLanguageFr.classList.remove("selected");
                classicLanguageEs.classList.remove("selected");
                classicLanguageTl.classList.remove("selected");
                classicLanguage.value = "en";
            }
        }
        else if(div.id == "classicLanguageFr") {
            if(!isSelected) {
                div.classList.toggle("selected");
                classicLanguageEn.classList.remove("selected");
                classicLanguageEs.classList.remove("selected");
                classicLanguageTl.classList.remove("selected");
                classicLanguage.value = "fr";
            }
        }
        else if(div.id == "classicLanguageEs") {
            if(!isSelected) {
                div.classList.toggle("selected");
                classicLanguageEn.classList.remove("selected");
                classicLanguageFr.classList.remove("selected");
                classicLanguageTl.classList.remove("selected");
                classicLanguage.value = "es";
            }
        }
        else if(div.id == "classicLanguageTl") {
            if(!isSelected) {
                div.classList.toggle("selected");
                classicLanguageEn.classList.remove("selected");
                classicLanguageFr.classList.remove("selected");
                classicLanguageEs.classList.remove("selected");
                classicLanguage.value = "tl";
            }
        }
    };


    self.toggleSelectedLanguage = function(e) {
        var div = e.target;
        var player1Language = document.getElementsByName("player1Language")[0];
        var player2Language = document.getElementsByName("player2Language")[0];
        var player1LanguageEn = document.getElementById("player1LanguageEn");
        var player1LanguageFr = document.getElementById("player1LanguageFr");
        var player1LanguageEs = document.getElementById("player1LanguageEs");
        var player1LanguageTl = document.getElementById("player1LanguageTl");
        var player2LanguageEn = document.getElementById("player2LanguageEn");
        var player2LanguageFr = document.getElementById("player2LanguageFr");
        var player2LanguageEs = document.getElementById("player2LanguageEs");
        var player2LanguageTl = document.getElementById("player2LanguageTl");

        // var player2Languages = document.getElementById("player2_language_config");
        // var selectedLanguageP2 = player2Languages.getElementsByClassName("example");

        var isSelected = div.classList.contains('selected');

        if(div.id == "player1LanguageFr") {
            if(!isSelected) {
                div.classList.toggle("selected");
                player1LanguageEn.classList.remove("selected");
                player1LanguageEs.classList.remove("selected");
                player1LanguageTl.classList.remove("selected");
                player1Language.value = "fr";
                self.disablePlayerLanguage(div.id);
            }

        }
        else if(div.id == "player1LanguageEn"){
            if(!isSelected) {
                div.classList.toggle("selected");
                player1LanguageFr.classList.remove("selected");
                player1LanguageEs.classList.remove("selected");
                player1LanguageTl.classList.remove("selected");
                player1Language.value = "en";
                self.disablePlayerLanguage(div.id);
            }
        }
        else if(div.id == "player1LanguageEs"){
            if(!isSelected) {
                div.classList.toggle("selected");
                player1LanguageFr.classList.remove("selected");
                player1LanguageEn.classList.remove("selected");
                player1LanguageTl.classList.remove("selected");
                player1Language.value = "es";
                self.disablePlayerLanguage(div.id);
            }
        }
        else if(div.id == "player1LanguageTl"){
            if(!isSelected) {
                div.classList.toggle("selected");
                player1LanguageFr.classList.remove("selected");
                player1LanguageEn.classList.remove("selected");
                player1LanguageEs.classList.remove("selected");
                player1Language.value = "tl";
                self.disablePlayerLanguage(div.id);
            }
        }
        else if(div.id == "player2LanguageFr") {
             if(!isSelected) {
                 div.classList.toggle("selected");
                 player2LanguageEn.classList.remove("selected");
                 player2LanguageEs.classList.remove("selected");
                 player2LanguageTl.classList.remove("selected");
                player2Language.value = "fr";
                self.disablePlayerLanguage(div.id);
             }
        }
        else if(div.id == "player2LanguageEn"){
            if(!isSelected) {
                div.classList.toggle("selected");
                player2LanguageFr.classList.remove("selected");
                player2LanguageEs.classList.remove("selected");
                player2LanguageTl.classList.remove("selected");
                player2Language.value = "en";
                self.disablePlayerLanguage(div.id);
            }
        }
        else if(div.id == "player2LanguageEs"){
            if(!isSelected) {
                div.classList.toggle("selected");
                player2LanguageFr.classList.remove("selected");
                player2LanguageEn.classList.remove("selected");
                player2LanguageTl.classList.remove("selected");
                player2Language.value = "es";
                self.disablePlayerLanguage(div.id);
            }
        }
        else if(div.id == "player2LanguageTl"){
            if(!isSelected) {
                div.classList.toggle("selected");
                player2LanguageFr.classList.remove("selected");
                player2LanguageEn.classList.remove("selected");
                player2LanguageEs.classList.remove("selected");
                player2Language.value = "tl";
                self.disablePlayerLanguage(div.id);
            }
        }
    };

    self.setLanguage = function(lang) {
        var activatedLanguagesDiv = document.getElementById("activatedLanguages");
        if(activatedLanguagesDiv) {
            activatedLanguagesDiv.innerHTML = lang;
        }
    };

    self.showErrorMessage = function(message) {
        var errorMessagePopupDiv = document.getElementById("showModalDialog");
        var messageDiv = document.getElementById('messageText');

        if(errorMessagePopupDiv) {
            _windowOpened = 'errorMessageWindow';
            messageDiv.innerHTML = message;
            errorMessagePopupDiv.style.display = "block";

            //play sound
            self.sound.openPopupInGame();
        }
    };

    self.showNotImplementedPopup = function(e) {
        if(_languageSet == null) {
            self.getAppLanguage();
            self.updateGameTexts();
            self.updateGameButtonLocale();
        }
        var notImplementedPopupDiv = document.getElementById("showModalDialog");
        var messageDiv = document.getElementById('messageText');
        var language = window.applanguage[_languageSet];
        var notAvailableTxt = language.notyetavailable;
        var helpImplementTxt = language.helpusimplement;


        messageDiv.innerHTML = notAvailableTxt + ", <a id='tipeeeLink' href='https://www.tipeee.com/manatygames' class='url' target='blank'>" + helpImplementTxt + "</a>.";

        if(notImplementedPopupDiv) {
            _windowOpened = 'notImplementedWindow';

            notImplementedPopupDiv.style.display = "block";

            //play sound
            self.sound.openPopupInGame();
        }
    };

    self.hideNotImplementedPopup = function(e) {
        var notImplementedPopupDiv = document.getElementById("showModalDialog");

        if(notImplementedPopupDiv) {
            _windowOpened = 'mainMenuWindow';

            notImplementedPopupDiv.style.display = "none";

            //play sound
            self.sound.openPopupInGame();
        }
    };

    self.openCredits = function(e) {

        self.mainMenuDiv.style.display = 'none';
        self.creditsScreen.style.display = 'block';
    };

    self.backToMainMenu = function(e) {
        self.creditsScreen.style.display = 'none';
        self.mainMenuDiv.style.display = 'block';
    };

    self.soloPlaySelected = function(e) {
        self.gameType = "soloPlay";
        self.localStorage.setItem("soloPlay", true);
        self.showGameModeScreen();
    }

    self.passAndPlaySelected = function(e) {
        self.gameType = "passAndPlay";
        self.localStorage.setItem("soloPlay", false);
        self.showGameModeScreen();
    };

    self.showGameModeScreen = function(e) {
        if(_languageSet == null) {
            self.getAppLanguage();
            self.updateGameTexts();
            self.updateGameButtonLocale();
        }

        var language = window.applanguage[_languageSet];

        var gameConfigHeaderDiv = document.getElementById("gameConfigHeader");
        var headerPlayer2Div = document.getElementById("headerPlayer2");
        var player2NameInputDiv = document.getElementById("player2NameInput");
        var difficultySelectionDiv = document.getElementById("difficultySelection");

        if(self.gameType == "passAndPlay") {
            gameConfigHeaderDiv.innerHTML = language.passDeviceToPlay;
            headerPlayer2Div.innerHTML = language.player2;
            player2NameInputDiv.style.display = "block";
            difficultySelectionDiv.style.display = "none";

        }
        else {
            gameConfigHeaderDiv.innerHTML = language.playAgainstComputer;
            headerPlayer2Div.innerHTML = language.computer;
            player2NameInputDiv.style.display = "none";
            difficultySelectionDiv.style.display = "block";
            document.getElementById("size_1").checked = true;
            for(var i=0; i < 5; i++) {
                if(self.localStorage.getItem("aiDifficulty") == i) {
                  document.getElementById("size_"+(i+1)).checked = true;
                }
            }
        }


        _windowOpened = 'gameConfigPopupWindow';


        self.mainMenuDiv.style.display = 'none';
        self.gameModeScreen.style.display = "block";
        self.setPlayerInfoFromStorage();
        self.sound.openPopupInGame();

        //play sound
        self.sound.openPopupInGame();

    };

    self.hideGameModeScreen = function(e) {
        self.gameModeScreen.style.display = "none";
        self.mainMenuDiv.style.display = 'block';

        _windowOpened = 'mainMenuWindow';

        //play sound
        self.sound.openPopupInGame();
    };

    self.showGameConfigPopup = function(e) {
        self.toggleGameMode(document.getElementById("passAndPlayTab"));
        var gameConfigPopupDiv = document.getElementById("gameConfigModal");

        self.setPlayerInfoFromStorage();
        self.localStorage.setItem("soloPlay", false);
        if(gameConfigPopupDiv) {
            _windowOpened = 'gameConfigPopupWindow';

            gameConfigPopupDiv.style.display = "block";

            //play sound
            self.sound.openPopupInGame();
        }
    };



    self.showGameConfigPopupSolo = function(e) {
      self.toggleGameMode(document.getElementById("playAgainstComputerTab"));
        var gameConfigPopupDiv = document.getElementById("gameConfigModal");

        self.setPlayerInfoFromStorage();
        self.localStorage.setItem("soloPlay", true);
        if(gameConfigPopupDiv) {
            _windowOpened = 'gameConfigPopupWindow';

            gameConfigPopupDiv.style.display = "block";

            //play sound
            self.sound.openPopupInGame();
        }
    };

    self.hideGameConfigPopup = function(e) {
        var gameConfigPopupDiv = document.getElementById("gameConfigModal");

        if(gameConfigPopupDiv) {
            _windowOpened = 'mainMenuWindow';

            gameConfigPopupDiv.style.display = "none";

            //play sound
            self.sound.openPopupInGame();
        }
    };

    self.showMarbbleClassicModeOptions = function(e) {
        self.gameModeIcon.classList.remove('classic-icon');
        self.gameModeIcon.classList.add('marbble-classic-icon');

        var language = window.applanguage[_languageSet];

        self.gameMode = "MarbbleClassic";
        self.gameModeText.innerHTML = language.marbbleClassic;
        self.setActiveMode(self.marbbleClassicBtn);
        var player1LanguageRow =  document.getElementById('player1LanguageRow');
        var player2LanguageRow = document.getElementById('player2LanguageRow');
        var classicLanguageRow = document.getElementById('classicLanguageRow');

        if(player1LanguageRow) {
            player1LanguageRow.style.display = "block";
        }
        if(player2LanguageRow) {
            player2LanguageRow.style.display = "block";
        }

        if(classicLanguageRow) {
            classicLanguageRow.style.display = "none";
        }

        self.gamePlayBtn.style.opacity = 1.0;
    };

    self.selectMarbbleClassicMode = function(e) {
        self.gameMode = "MarbbleClassic";

        var gameModeSelected = document.getElementById("gameModeSelected");
        if(gameModeSelected) {
            gameModeSelected.value = self.gameMode;
        }
        self.showMarbbleClassicModeOptions();

    };

    self.setActiveMode = function(div) {

        self.marbbleClassicBtn.classList.remove('active');
        self.marbbleSpecialBtn.classList.remove('active');
        self.classicBtn.classList.remove('active');
        div.classList.toggle('active');

    };

    self.selectMarbbleSpecialMode = function(e) {
        self.showNotImplementedPopup();
        return;
        console.log(self.gameMode + ' selected...');
        self.gameModeText.innerHTML = "The ultimate Marbble challenge: two languages but one bag of tiles!";
        self.setActiveMode(self.marbbleSpecialBtn);
    };

    self.showClassicModeOptions = function(e) {
        self.gameModeIcon.classList.remove('marbble-classic-icon');
        self.gameModeIcon.classList.add('classic-icon');

        var language = window.applanguage[_languageSet];

        self.gameModeText.innerHTML = language.classicMode;
        self.setActiveMode(self.classicBtn);
        var player1LanguageRow =  document.getElementById('player1LanguageRow');
        var player2LanguageRow = document.getElementById('player2LanguageRow');
        var classicLanguageRow = document.getElementById('classicLanguageRow');
        if(player1LanguageRow) {
            player1LanguageRow.style.display = "none";
        }
        if(player2LanguageRow) {
            player2LanguageRow.style.display = "none";
        }

        if(classicLanguageRow) {
            classicLanguageRow.style.display = "block";
        }

        //self.gamePlayBtn.style.opacity = 0.5;
    };

    self.selectClassicMode = function(e) {
        self.gameMode = "Classic";

        var gameModeSelected = document.getElementById("gameModeSelected");
        if(gameModeSelected) {
            gameModeSelected.value = self.gameMode;
        }

        self.showClassicModeOptions();

    };

    /**
     * Get local storage. Return null if it cannot be supported
     */
    self.getSupportedLocalStorage = function()
    {
        try
        {
        	var localStorage = window.localStorage;
        	var testKey = 'isLocalStorageSupported';
        	localStorage.setItem(testKey, '1');
        	localStorage.removeItem(testKey);
            return localStorage;
        }
        catch (error)
        {
        	console.log(error);
        	console.log("Local storage may not be supported");
            return null;
        }
    }

    self.startManatySplash = function() {
        var isRunningOnBrowser = window.__cordovaRunningOnBrowser__;

        if(!isRunningOnBrowser) {
            if (/Android/i.test(navigator.userAgent)) {
                self.manatySplashScreen.classList.add('displaySplashScreen');
                setTimeout(self.startMarbbleSplash, 3000);
            }
            else if(/iPhone|iPod/i.test(navigator.userAgent)){
                self.marbbleSplashScreen.classList.add('displaySplashScreen');
                setTimeout(function(e) {
                    self.marbbleSplashScreen.classList.remove('displaySplashScreen');
                    self.marbbleSplashScreen.classList.add('hideSplashScreen');
                    self.mainMenuDiv.classList.add('displayNextPage');
                }, 3000);


            } else {
                self.mainMenuDiv.style.display = 'block';
            }
        }
        else {
            self.mainMenuDiv.style.display = 'block';
        }
    }

    self.startMarbbleSplash = function() {
        self.manatySplashScreen.classList.remove('displaySplashScreen');
        self.manatySplashScreen.classList.add('hideSplashScreen');
        self.marbbleSplashScreen.classList.add('displaySplashScreen');

        setTimeout(function(e) {
            self.marbbleSplashScreen.classList.remove('displaySplashScreen');
            self.marbbleSplashScreen.classList.add('hideSplashScreen');
            self.mainMenuDiv.classList.add('displayNextPage');
        }, 3000);

    }

    self.tipeeeLinkClick = function() {
        var ref = cordova.InAppBrowser.open('https://www.tipeee.com/manatygames', '_system', 'location=yes', 'hardwareback=no');
    }

    self.getPreferredLanguageSuccessCallback = function(language) {

        console.log("raw language value: " + language.value);
        if(language.value.indexOf('fr') != -1) {
            //language is fr;
            _languageSet = "fr";
        }
        else {
            _languageSet = "en";
        }

        var isRunningOnBrowser = window.__cordovaRunningOnBrowser__;

        if(!isRunningOnBrowser) {
            self.updateGameTexts();
            self.updateGameButtonLocale();
        }

    };

    self.getPreferedLanguageErrorCallback = function() {
        console.log('error getting language');
    };

    self.getBrowserLanguagePreference = function() {
        console.log('setting language from browser...');
        var userLang = navigator.languages ? navigator.languages[0] : (navigator.language || navigator.userLanguage);

        if(userLang.indexOf('fr') != -1) {
            //language is french;
            _languageSet = "fr";
        }
        else {
            _languageSet = "en";
        }
    };

    self.getUrlLanguage = function() {
        var pathArray = null;
        var preferredLanguage = "en";


        if(self.parentUrl != "") {
            pathArray = self.parentUrl.split('/');
        }
        else {
            return false;
        }

        if(pathArray) {

            if(pathArray[pathArray.length - 1].indexOf("index") != -1) {
                return false;
            }
            if(pathArray[pathArray.length - 1].indexOf("fr") != -1) {
                preferredLanguage = "fr";
                _languageSet = preferredLanguage;
                console.log('getting preferred language: ' + preferredLanguage);
                return true;
            }
            else {
                _languageSet = preferredLanguage;
                console.log('getting preferred language: ' + preferredLanguage);
                return true;
            }

        }
        else {
            return false;
        }
    }

    self.getAppLanguage = function() {
        if(_languageSet == null) {

            var preferredLanguage = self.getUrlLanguage();
            if(!preferredLanguage) {
                self.getBrowserLanguagePreference();
            }

        }

    };

    self.updateGameButtonLocale = function() {

        var mainMenuBtnDiv = document.getElementById("mainMenuBtn");
        var newGameBtnDiv = document.getElementById("newGameBtn");
        var settingsBtnDiv = document.getElementById("settingsBtn");
        var playWithFriendBtn = document.getElementById("playWithFriend");
        var findOpponentBtn = document.getElementById("findOpponent");
        var soloGameBtn = document.getElementById("soloGame");
        var passAndPlayBtn = document.getElementById("passAndPlayBtn");
        var activatedLanguagesDiv = document.getElementById("activatedLanguagesTitle");
        var editLanguagesBtn = document.getElementById("editLanguagesBtn");
        var gamePlayBtn = document.getElementById("gamePlayBtn");
        var cancelGameBtn = document.getElementById("cancelGameBtn");

        if(_languageSet == "fr") {

            if(mainMenuBtnDiv) {
                mainMenuBtnDiv.classList.remove('mainMenuBtn');
                mainMenuBtnDiv.classList.add('mainMenuBtn-fr');
            }

            if(newGameBtnDiv) {
                newGameBtnDiv.classList.remove('newGameBtn');
                newGameBtnDiv.classList.add('newGameBtn-fr');
            }

            if(settingsBtnDiv) {
                settingsBtnDiv.classList.remove('settingsBtn');
                settingsBtnDiv.classList.add('settingsBtn-fr');
            }

            if(playWithFriendBtn) {
                playWithFriendBtn.classList.remove('playWithFriendBtn');
                playWithFriendBtn.classList.add('playWithFriendBtn-fr');
            }

            if(findOpponentBtn) {
                findOpponentBtn.classList.remove('findOpponentBtn');
                findOpponentBtn.classList.add('findOpponentBtn-fr');
            }

            if(soloGameBtn) {
                soloGameBtn.classList.remove('soloGameBtn');
                soloGameBtn.classList.add('soloGameBtn-fr');
            }

            if(passAndPlayBtn) {
                passAndPlayBtn.classList.remove('passNplayBtn');
                passAndPlayBtn.classList.add('passNplayBtn-fr');
            }

            if(activatedLanguagesDiv) {
                activatedLanguagesDiv.classList.remove('activated_languages_title');
                activatedLanguagesDiv.classList.add('activated_languages_title-fr');
            }

            if(editLanguagesBtn) {
                editLanguagesBtn.classList.remove('edit_languages');
                editLanguagesBtn.classList.add('edit_languages-fr');
            }

            if(gamePlayBtn) {
                gamePlayBtn.classList.remove('lets-play-btn');
                gamePlayBtn.classList.add('lets-play-btn-fr');
            }

            if(cancelGameBtn) {
                cancelGameBtn.classList.remove('config-cancel-btn');
                cancelGameBtn.classList.add('config-cancel-btn-fr');
            }
        }
    };

    self.updateGameTexts = function() {

        var language = window.applanguage[_languageSet];


        //CREDITS
        var financingTextDiv = document.getElementById('financingTxt');
        var conceptTextDiv = document.getElementById('conceptTxt');
        var projectLeadTextDiv = document.getElementById('projectLeadTxt');
        var developmentTextDiv = document.getElementById('developmentTxt');
        var designTextDiv = document.getElementById('designTxt');
        var infrastructureTextDiv = document.getElementById('infrasctureTxt');
        var notAvailableTextDiv = document.getElementById('notAvailableTxt');
        var helpImplementTextDiv = document.getElementById('helpImplementTxt');
        var playSoundTextDiv = document.getElementById('playSoundTxt');
        var player1TextDiv = document.getElementById('player1Txt');
        var player1NameText = document.getElementById('player1NameTxt');
        var player2NameText = document.getElementById('player2NameTxt');
        var player1LanguageText = document.getElementById('player1LanguageTxt');
        var player2LanguageText = document.getElementById('player2LanguageTxt');
        var classicLanguageText = document.getElementById('classicLanguageTxt');
        var player1Pseudo = document.getElementById('player1pseudo');
        var player2Pseudo = document.getElementById('player2pseudo');
        var difficultyTextDiv = document.getElementById('difficultyTxt');
        var exitAppTextDiv = document.getElementById('exitAppTxt');
        var computerIsPlayingTxt = document.getElementById('computerIsPlayingTxt');


        if(financingTextDiv) {
            financingTextDiv.innerHTML = language.financing;
        }
        if(conceptTextDiv) {
            conceptTextDiv.innerHTML = language.concept;
        }
        if(projectLeadTextDiv) {
            projectLeadTextDiv.innerHTML = language.projectlead;
        }
        if(developmentTextDiv) {
            developmentTextDiv.innerHTML = language.development;
        }
        if(designTextDiv) {
            designTextDiv.innerHTML = language.design;
        }
        if(infrastructureTextDiv) {
            infrastructureTextDiv.innerHTML = language.infrastructure;
        }

        if(notAvailableTextDiv) {
            notAvailableTextDiv.innerHTML = language.notyetavailable;
        }

        if(helpImplementTextDiv) {
            helpImplementTextDiv.innerHTML = language.helpusimplement;
        }

        if(playSoundTextDiv) {
            playSoundTextDiv.innerHTML = language.playSound;
        }

        if(player1TextDiv) {
            player1TextDiv.innerHTML = language.player1;
        }

        if(player1NameText) {
            player1NameText.innerHTML = language.name;
        }

        if(player2NameText) {
            player2NameText.innerHTML = language.name;
        }

        if(player1LanguageText) {
            player1LanguageText.innerHTML = language.language;
        }

        if(player2LanguageText) {
            player2LanguageText.innerHTML = language.language;
        }

        if(classicLanguageText) {
            classicLanguageText.innerHTML = language.language;
        }

        if(player1Pseudo) {
            player1Pseudo.placeholder = language.enterPseudo;
        }

        if(player2Pseudo) {
            player2Pseudo.placeholder = language.enterPseudo;
        }

        if(difficultyTextDiv) {
            difficultyTextDiv.innerHTML = language.difficulty;
        }

        if(computerIsPlayingTxt) {
            computerIsPlayingTxt.innerHTML = language.computerIsPlaying;
        }

        if(exitAppTextDiv) {
            exitAppTextDiv.innerHTML = language.exitapp;
        }


    };

    self.init();

    return self;
};
